const postData = require("./posts");
const animalData = require("./animals");

module.exports = {
  animals: animalData,
  posts: postData
};